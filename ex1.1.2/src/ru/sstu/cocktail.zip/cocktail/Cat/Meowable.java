package ru.sstu.cocktail.Cat;

public interface Meowable {
    void meow();
}
