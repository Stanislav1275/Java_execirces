package ru.sstu.cocktail.homeworks_ermakov;

public class StartQeust {
}
