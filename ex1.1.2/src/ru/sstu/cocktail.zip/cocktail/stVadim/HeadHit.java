package ru.sstu.cocktail.stVadim;

public class HeadHit implements Bully{
    @Override
    public String hit(String name) {
        return name + " head";
    }
}
