package ru.sstu.cocktail.stVadim;

public class FeetHit implements Bully{
    @Override
    public String hit(String name) {
        return name + " feet";
    }
}
