package ru.sstu.cocktail.fifth_head;

public class Storage<T> {
    private final T object;
    private final T alternative;
    private final Defaultable rule;

    public Storage(T object, T alternative, Defaultable<T> rule) {
        this.object = object;
        if (alternative == null) {
            throw new IllegalArgumentException("alternative must be not null");
        }
        this.alternative = alternative;
        this.rule = (rule == null) ? (Defaultable<T>) (o, a) -> (o == null) ? a : o : rule;
    }

    public Storage(T object, T alternative) {
        this(object, alternative, null);
    }

    public T getObject() {
        return (T) rule.getDefault(object, alternative);
    }

}
