package ru.sstu.cocktail.fifth_head;

public interface MyComparable<T> {
    int compare(T c);
}
