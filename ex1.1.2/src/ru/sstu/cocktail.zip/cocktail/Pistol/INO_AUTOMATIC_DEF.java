package ru.sstu.cocktail.Pistol;

public interface INO_AUTOMATIC_DEF {
    String SHOOT_EFFECT = "БАХ";
    String PATRONS_IS_GONE_EFFECT = "КЛАЦ";
    int DEFAULT_PATRONS_COUNT = 5;
}
