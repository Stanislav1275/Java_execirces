package ru.sstu.cocktail.Pistol;

public interface IAUTOMATIC_DEF extends INO_AUTOMATIC_DEF{
    static final int DEF_RATE_COUNT = 30;
    static public int DEFAULT_PATRONS_COUNT = 30;

}
