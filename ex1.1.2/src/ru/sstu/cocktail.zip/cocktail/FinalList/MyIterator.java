package ru.sstu.cocktail.FinalList;

public class MyIterator {
}
