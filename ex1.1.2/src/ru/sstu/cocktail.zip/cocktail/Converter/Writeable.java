package ru.sstu.cocktail.Converter;

public interface Writeable {
    void write();
}
