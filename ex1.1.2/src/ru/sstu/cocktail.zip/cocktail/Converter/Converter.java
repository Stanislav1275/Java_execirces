package ru.sstu.cocktail.Converter;

public class Converter{
    public Readable read;
    public Converter(Readable data) {
    }

    public void read(Handleable handler){

    }

}
