package ru.sstu.cocktail.Converter;

public interface Handleable extends Writeable, Readable, Changeable{
}
