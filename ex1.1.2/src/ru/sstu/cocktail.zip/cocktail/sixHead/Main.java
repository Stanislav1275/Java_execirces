package ru.sstu.cocktail.sixHead;

import ru.sstu.cocktail.sixHead.Commands.Action;
import ru.sstu.cocktail.sixHead.Commands.addMark;
import ru.sstu.cocktail.sixHead.Commands.removeMark;

public class Main {
    public static void main(String[] args) {
        Student<Integer> st = new Student<>("name", mark -> mark > 1);
        Switch <addMark, removeMark>swAddRemove = new Switch<>(new addMark(st), new removeMark(st));
        swAddRemove.flipUpCommand.execute(5);
        swAddRemove.flipDownCommand.execute(0);
        System.out.println(st.getMarks());

    }
}
