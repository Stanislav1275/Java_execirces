package ru.sstu.cocktail.sixHead;

import ru.sstu.cocktail.sixHead.Commands.addMark;
import ru.sstu.cocktail.sixHead.Commands.removeMark;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 212013
 */
public class Student<T>{
    ArrayDeque<String> undo = new ArrayDeque<>();
    ArrayDeque<String> redo = new ArrayDeque<>();
    ArrayDeque<Switch<addMark, removeMark>> global = new ArrayDeque<>();
    Switch <addMark, removeMark>swAddRemove;
    String name;
    Ruleable rule;
    List<Integer> marks = new ArrayList<>();

    public Student(String name, Ruleable rule) {
        this.name = name;
        this.rule = rule;
        this.swAddRemove = new Switch<>(new addMark(this), new removeMark(this));
    }

    public List<Integer> getMarks() {
        return marks;
    }

    public void addMark(int index,Integer mark) {
       if (rule.check(mark)) {
            marks.add(mark);
        } else {
            throw new IllegalArgumentException("Ahtung");
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public void delMark(int x) {
        marks.remove(x);
    }


}
