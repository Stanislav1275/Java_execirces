package ru.sstu.cocktail.sixHead;

public interface Ruleable {
    boolean check(Integer mark);
}