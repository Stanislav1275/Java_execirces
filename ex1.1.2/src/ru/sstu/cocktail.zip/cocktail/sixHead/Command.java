package ru.sstu.cocktail.sixHead;

public interface Command {
    void execute();

}
