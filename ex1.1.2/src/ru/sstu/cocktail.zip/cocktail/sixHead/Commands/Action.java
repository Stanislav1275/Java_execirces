package ru.sstu.cocktail.sixHead.Commands;

import ru.sstu.cocktail.sixHead.Command;

public abstract class Action<T> implements Command {
    public T object;
    @Override
    public abstract void  execute();

    public Action(T object) {
        this.object = object;
    }
}
