package ru.sstu.cocktail.ex_1_3_.City_1_3_3;

public interface Algs {
    City[] findWay(City city1, City city2);

}
