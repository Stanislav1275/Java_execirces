package ru.sstu.cocktail.ex_1_3_.City_1_3_3;

public class Algorithms {

}
