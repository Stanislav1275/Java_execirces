package ru.sstu.cocktail.Temporary;

public class Default extends Temp{
    public Default(String tmpInfo, int min, int max) {
        super(tmpInfo, min, max);
    }
}
