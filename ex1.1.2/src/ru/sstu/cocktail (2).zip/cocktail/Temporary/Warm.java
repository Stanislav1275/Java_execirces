package ru.sstu.cocktail.Temporary;

public class Warm extends Temp{
    public Warm(String tmpInfo, int min, int max) {
        super(tmpInfo, min, max);
    }
}
