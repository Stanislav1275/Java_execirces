package ru.sstu.cocktail.Temporary;

public class Cold extends Temp {

    public Cold(String tmpInfo, int min, int max) {
        super(tmpInfo, min, max);
    }
}
