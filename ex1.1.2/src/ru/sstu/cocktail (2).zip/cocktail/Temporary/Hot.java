package ru.sstu.cocktail.Temporary;

public class Hot extends Temp{

    public Hot(String tmpInfo, int min, int max) {
        super(tmpInfo, min, max);
    }
}
