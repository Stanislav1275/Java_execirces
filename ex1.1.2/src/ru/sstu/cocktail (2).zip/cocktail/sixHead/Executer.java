package ru.sstu.cocktail.sixHead;

public class Executer {
    public void execute(Command command) {
        command.execute();
    }
}
