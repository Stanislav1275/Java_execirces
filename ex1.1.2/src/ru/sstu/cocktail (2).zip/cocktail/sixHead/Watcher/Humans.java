package ru.sstu.cocktail.sixHead.Watcher;

public interface Humans {

    boolean accept(Operation operation);

}
