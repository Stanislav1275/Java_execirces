package ru.sstu.cocktail.sixHead.Watcher;

public interface Rule {
}
