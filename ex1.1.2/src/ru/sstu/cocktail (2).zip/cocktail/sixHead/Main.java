package ru.sstu.cocktail.sixHead;

//import ru.sstu.cocktail.sixHead.Commands.Action;


import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {


    }
}
