package ru.sstu.cocktail.sixHead;

import java.util.List;

public interface Avegatorable<T> {
    T getAverage(T... list);
}
