package ru.sstu.cocktail.sixHead;

public class DefaultWithNull<T> extends Default<T>{
    DefaultWithNull(){
        super(null);
    }
}
