package ru.sstu.cocktail.sixHead.TraficLight;

public interface Colorable {

    Colorable next();


}
