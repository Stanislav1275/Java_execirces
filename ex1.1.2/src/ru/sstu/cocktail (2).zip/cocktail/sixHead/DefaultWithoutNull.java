//package ru.sstu.cocktail.sixHead;
//
//public class DefaultWithoutNull<T> extends Default<T> {
//}
