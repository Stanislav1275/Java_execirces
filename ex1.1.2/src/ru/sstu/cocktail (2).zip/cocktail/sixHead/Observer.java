package ru.sstu.cocktail.sixHead;

public interface Observer {
    void addChild(Subjectable child);
}
