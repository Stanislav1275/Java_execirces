package ru.sstu.cocktail.sixHead;

public interface Subjectable<T> {
    void passRes(T mark);
}
