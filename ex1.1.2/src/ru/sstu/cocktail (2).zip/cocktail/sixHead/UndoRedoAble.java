package ru.sstu.cocktail.sixHead;

public interface UndoRedoAble {
    void redo();
    void undo();
}
