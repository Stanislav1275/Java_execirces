package ru.sstu.cocktail.sixHead.Watcher1;

public interface Rule <T>{
    boolean isAccept(T object);
}
