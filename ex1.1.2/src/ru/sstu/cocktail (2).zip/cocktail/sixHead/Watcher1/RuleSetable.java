package ru.sstu.cocktail.sixHead.Watcher1;

public interface RuleSetable<T> {
    void setRule(Rule <T> t);
}
