package ru.sstu.cocktail.sixHead.Stock;

public interface Observer {
    void update(String stockname, String news);
}
