package ru.sstu.cocktail.sixHead;

public interface Ruleable<T> {
    boolean check(T mark);
}