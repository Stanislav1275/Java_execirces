package ru.sstu.cocktail.sixHead;

public enum CommandCategory {
    NAME, ADDMARKS, DELMARKS;
}
