//package ru.sstu.cocktail.sixHead.Commands;
//
//import ru.sstu.cocktail.sixHead.Command;
//import ru.sstu.cocktail.sixHead.Student;
//
//public class addMark implements Command{
//
//
//    public Student<?> st;
//
//    public void execute(int index, int value) {
//        st.addMark(index,value);
//    }
//
//    public addMark(Student<?> st) {
//        this.st = st;
//    }
//
//    @Override
//    public void execute() {
//
//    }
//}
