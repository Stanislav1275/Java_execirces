package ru.sstu.cocktail.FinalList;

public class FinalList {
}
