package ru.sstu.cocktail.ex_1_1_;

public interface IPoint extends IPoint2d, IPoint3D{

}
