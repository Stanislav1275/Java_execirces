package ru.sstu.cocktail.ex_1_1_;

public interface IPoint2d {
    void shiftCoords(double xOffset, double yOffset);
}
