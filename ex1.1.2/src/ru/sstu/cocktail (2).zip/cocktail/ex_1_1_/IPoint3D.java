package ru.sstu.cocktail.ex_1_1_;

public interface IPoint3D {
    void shiftCoords(double xOffset, double yOffset, double zOffset);
}
