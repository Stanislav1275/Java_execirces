package ru.sstu.cocktail.ex_1_1_;

public class NameGenerator {


}
