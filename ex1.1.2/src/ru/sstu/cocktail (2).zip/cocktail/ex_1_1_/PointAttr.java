package ru.sstu.cocktail.ex_1_1_;

public class PointAttr {
    private Object value;
//    private String key;

    public Object getObject() {
        return value;
    }

    public void setObject(Object value) {
        this.value = value;
    }
}
