package ru.sstu.cocktail.Birds;

public interface IBird {
    void song();
}
