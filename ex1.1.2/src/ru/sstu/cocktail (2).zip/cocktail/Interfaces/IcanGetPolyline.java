package ru.sstu.cocktail.Interfaces;

import ru.sstu.cocktail.ex_1_3_.Broken;

public interface IcanGetPolyline {
    Broken getBroken();
}
