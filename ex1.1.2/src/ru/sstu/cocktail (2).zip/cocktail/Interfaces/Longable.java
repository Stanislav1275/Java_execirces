package ru.sstu.cocktail.Interfaces;

public interface Longable {
    double getLength();
}
