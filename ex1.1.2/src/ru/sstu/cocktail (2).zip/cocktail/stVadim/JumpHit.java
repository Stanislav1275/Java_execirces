package ru.sstu.cocktail.stVadim;

public class JumpHit implements Bully{
    @Override
    public String hit(String name) {
        return name + " jump";
    }
}
