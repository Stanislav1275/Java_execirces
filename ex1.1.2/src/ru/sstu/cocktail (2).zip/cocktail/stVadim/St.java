package ru.sstu.cocktail.stVadim;

public class St {
}
