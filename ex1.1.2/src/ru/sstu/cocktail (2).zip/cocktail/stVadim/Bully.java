package ru.sstu.cocktail.stVadim;

public interface Bully {
    public String hit(String name);
}
