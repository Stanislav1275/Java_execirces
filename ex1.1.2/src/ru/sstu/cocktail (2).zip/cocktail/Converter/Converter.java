//package ru.sstu.cocktail.Converter;
//
//public final class Converter {
//    private Readable reader;
//    private ChangeHandler changer;
//    private Writeable writer;
//
//    public Converter(Readable reader, ChangeHandler changer, Writeable writer) {
//        writer.write(changer.change(reader.read()));
//    }
//
//    }
//
//}
////Convetable img = new Img();
////Convetable qr = new Qr();
//// Convert conv = new Conv(img);
////conv.convert(qr);