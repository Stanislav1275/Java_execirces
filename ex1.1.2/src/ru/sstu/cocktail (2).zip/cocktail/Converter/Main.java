package ru.sstu.cocktail.Converter;

public class Main {
    public static void main(String[] args) {

    }
}
