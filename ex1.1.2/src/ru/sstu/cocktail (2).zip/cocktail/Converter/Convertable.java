package ru.sstu.cocktail.Converter;

public interface Convertable extends Readable, Changeable, Writeable{


}
