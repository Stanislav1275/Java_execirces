package ru.sstu.cocktail.Converter;

public interface Changeable {
    Convertable change();

}
