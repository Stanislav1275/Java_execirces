package ru.sstu.cocktail.Converter;

public interface Readable {
      Convertable read();

}
