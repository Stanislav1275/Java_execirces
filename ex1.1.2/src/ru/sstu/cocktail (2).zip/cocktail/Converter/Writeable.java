package ru.sstu.cocktail.Converter;

import java.io.Reader;

public interface Writeable {
    void write(Reader read);
}
